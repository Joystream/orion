module.exports = {
  singleQuote: true,
  arrowParens: 'always',
  useTabs: false,
  tabWidth: 2,
  semi: false,
  trailingComma: 'es5',
  quoteProps: 'preserve',
  printWidth: 100,
}
