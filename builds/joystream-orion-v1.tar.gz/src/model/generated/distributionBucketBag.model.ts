import {Entity as Entity_, Column as Column_, PrimaryColumn as PrimaryColumn_, ManyToOne as ManyToOne_, Index as Index_} from "typeorm"
import {DistributionBucket} from "./distributionBucket.model"
import {StorageBag} from "./storageBag.model"

@Index_(["distributionBucket", "bag"], {unique: true})
@Entity_()
export class DistributionBucketBag {
    constructor(props?: Partial<DistributionBucketBag>) {
        Object.assign(this, props)
    }

    /**
     * {distributionBucketId}-{storageBagId}
     */
    @PrimaryColumn_()
    id!: string

    @ManyToOne_(() => DistributionBucket, {nullable: true, deferrable: 'INITIALLY DEFERRED'})
    distributionBucket!: DistributionBucket

    @Column_({ nullable: true })
    distributionBucketId!: string | null | undefined

    @Index_()
    @ManyToOne_(() => StorageBag, {nullable: true, deferrable: 'INITIALLY DEFERRED'})
    bag!: StorageBag

    @Column_({ nullable: true })
    bagId!: string | null | undefined
}
