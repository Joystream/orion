export enum Continent {
    AF = "AF",
    NA = "NA",
    OC = "OC",
    AN = "AN",
    AS = "AS",
    EU = "EU",
    SA = "SA",
}
