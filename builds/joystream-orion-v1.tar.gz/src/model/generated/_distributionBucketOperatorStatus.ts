export enum DistributionBucketOperatorStatus {
    INVITED = "INVITED",
    ACTIVE = "ACTIVE",
}
