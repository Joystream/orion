export enum CommentStatus {
    VISIBLE = "VISIBLE",
    DELETED = "DELETED",
    MODERATED = "MODERATED",
}
