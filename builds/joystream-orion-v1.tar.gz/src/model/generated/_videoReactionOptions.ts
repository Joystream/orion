export enum VideoReactionOptions {
    LIKE = "LIKE",
    UNLIKE = "UNLIKE",
}
