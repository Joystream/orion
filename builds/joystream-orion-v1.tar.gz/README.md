# Orion V2

Orion V2 is a backed node powering [Atlas](https://github.com/Joystream/atlas).
The project is using [Subsquid framework](https://docs.subsquid.io/) and is based on [squid-substrate-template](https://github.com/subsquid/squid-substrate-template).

## [Developer guide](docs/developer-guide.md)
## [Operator guide](docs/operator-guide.md)